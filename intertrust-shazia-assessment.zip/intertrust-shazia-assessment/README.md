### Steps to Run application

1. unzip intertrust-shazia-assessment.zip
2. cd intertrust-shazia-assessment
3. npm i
4. Run client and server in 2 different terminal

     4.1 server:
    -> npm run server

    4.2 client:
    -> npm start

5. localhost:3000/
6. Run test cases in new terminal
    -> npm test