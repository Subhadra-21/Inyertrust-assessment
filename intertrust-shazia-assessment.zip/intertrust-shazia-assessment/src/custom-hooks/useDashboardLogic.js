import { useState, useEffect } from "react";
import { fetchEnergyData } from "../utils/fetchEnergyData";

const useDashboardLogic = () => {
  const [energyData, setEnergyData] = useState([]);

  useEffect(() => {
    fetchUtilEnergyData();
    const timerId = setInterval(() => {
      fetchUtilEnergyData();
    }, 5000);
    return () => {
      clearInterval(timerId);
    };
  }, []);

  async function fetchUtilEnergyData() {
    try {
      const data = await fetchEnergyData();
      setEnergyData(data?.data || []);
    } catch (err) {
      console.log("err", err);
    }
  }

  return {
    energyData,
  };
};

export default useDashboardLogic;
