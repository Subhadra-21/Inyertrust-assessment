/* eslint-disable import/first */
import React from "react";
import { findByTestId, render, screen } from "@testing-library/react";
import Dashboard from "../Dashboard/Dashboard";
import { energyData } from "../../mockApi/mockData";
import { fetchEnergyData } from "../../utils/fetchEnergyData";

jest.mock("../../utils/fetchEnergyData", () => {
  return {
    fetchEnergyData: jest.fn(),
  };
});

describe("Dashboard renders with mocked data", () => {
  it("check voltage, wattage and stats detais are correct", async () => {
    fetchEnergyData.mockResolvedValue({ data: energyData });
    render(<Dashboard />);

    //verify voltage
    const dataElement = await screen.findByTestId(
      `panel-voltage-${energyData[0].id}`
    );
    expect(dataElement).toHaveTextContent(
      `Voltage: ${energyData[0].voltage} volts`
    );

    ////verify wattage
    const dataWatElement = await screen.findByTestId(
      `panel-wattage-${energyData[0].id}`
    );
    expect(dataWatElement).toHaveTextContent(
      `Wattage: ${energyData[0].wattage} watts/hour`
    );

    //verify stats data
    let totalEnergy = energyData.reduce((prev, cur) => prev + parseFloat(cur.wattage), 0);
    totalEnergy = (totalEnergy / 1000).toFixed(2);
    const weakCount = energyData.filter(
      (d) => d.voltage < 10 && d.wattage < 200
    ).length;
    const healthyCount = energyData.length - weakCount;

     const totalElem = await screen.findByTestId("stats-total");
     const weakElem = await screen.findByTestId("stats-weak");
     const healthyElem = await screen.findByTestId("stats-healthy");

     expect(totalElem).toHaveTextContent(`Total Energy: ${totalEnergy} kWh`);
     expect(weakElem).toHaveTextContent(`Weak Panel Count: ${weakCount}`);
     expect(healthyElem).toHaveTextContent(`Healthy Panel Count: ${healthyCount}`);
  });
  it("Should show no panels message when no data", async () => {
    fetchEnergyData.mockResolvedValue({ data: [] });
    render(<Dashboard />);

    //verify no data message
    const dataElement = await screen.findByTestId("nodata");
    expect(dataElement).toHaveTextContent("No solar panels available.");  
  });
});
