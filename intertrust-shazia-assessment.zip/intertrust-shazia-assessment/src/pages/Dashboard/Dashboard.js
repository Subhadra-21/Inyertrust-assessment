import ParkOverview from "../../components/ParkOverview";
import PanelsGrid from "../../components/PanelsGrid";
import useDashboardLogic from "../../custom-hooks/useDashboardLogic";
import Container from "@mui/material/Container";
import "./Dashboard.css";

const Dashboard = () => {
    const {energyData} = useDashboardLogic();
  return (
    <Container>
        <h1 className="heading">Solar Panels Dashboard</h1>
        <ParkOverview energyData={energyData} />
        <PanelsGrid energyData={energyData} />
    </Container>
  )
}

export default Dashboard