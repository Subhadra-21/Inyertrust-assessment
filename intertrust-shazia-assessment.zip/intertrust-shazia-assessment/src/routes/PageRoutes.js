import {useRoutes} from "react-router-dom";
import Dashboard from "../pages/Dashboard/Dashboard.js";

const Routes = () => {
  const elements = useRoutes([
    {
        path: "/",
        element: <Dashboard />
    }
  ]);
  return elements;
}

export default Routes;