const energyData = [
    {
        "id": 101,
        "date": "2020-09-24",
        "time": "18:00:00",
        "energy": "3,078.600kWh",
        "efficiency": "5.131kWh/kW",
        "wattage": "985",
        "voltage": "7895"
      },
      {
        "id": 102,
        "date": "2020-09-24",
        "time": "18:00:00",
        "energy": "3,078.600kWh",
        "efficiency": "5.131kWh/kW",
        "wattage": "120",
        "voltage": "9"
      }
];

export {
    energyData
}