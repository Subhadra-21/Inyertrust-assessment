import axios from "axios";
export async function fetchEnergyData() {
    const data = await axios.get("/getEnergyData");
    return data;
}
