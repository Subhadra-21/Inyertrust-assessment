import PanelGridItem from "../PanelGridItem";
import "./index.css";

const PanelsGrid = ({energyData=[]}) => {

  return (
    <div className="panelsGrid">
        {energyData.length === 0 ? <div data-testid="nodata">No solar panels available.</div> : 
        <div className="gridContainer">
            {
                energyData.map(d => <PanelGridItem key={d.id} {...d}/>)
            }
        </div>
}

    </div>
  )
}

export default PanelsGrid;