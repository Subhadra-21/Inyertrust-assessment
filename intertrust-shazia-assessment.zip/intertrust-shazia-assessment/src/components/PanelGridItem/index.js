import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import "./index.css";

const PanelGridItem = ({wattage, voltage,id}) => {
    const isWeak = voltage < 10 && wattage < 200;
  return (
    <Card className={`panelCard ${isWeak? "weak" : "healthy"}`}>
        <CardContent>
            <p data-testid={`panel-voltage-${id}`}>Voltage: {voltage} volts</p>
            <p data-testid={`panel-wattage-${id}`}>Wattage: {wattage} watts/hour</p>
        </CardContent> 
    </Card>
  )
}

export default PanelGridItem;