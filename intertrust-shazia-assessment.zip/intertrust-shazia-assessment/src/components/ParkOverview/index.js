import PanelStatusChart from "./PanelStatusChart";
import PanelStatsSummary from "./PanelStatsSummary";
import { useMemo } from "react";
import "./index.css";

const ParkOverview = ({ energyData }) => {
  function prepData() {
    let totalEnergy = energyData.reduce((prev, cur) => prev + parseFloat(cur.wattage), 0);
    totalEnergy = (totalEnergy / 1000).toFixed(2);
    const weakCount = energyData.filter(
      (d) => d.voltage < 10 && d.wattage < 200
    ).length;
    const healthyCount = energyData.length - weakCount;
    const chartData = [
      {
        type: "pie",
        values: [weakCount, healthyCount],
        labels: ["Weak Panel", "Healthy Panel"],
        hoverinfo: "label+percent",
        // hole: .4,
        insidetextorientation: "radial",
        marker: {
          colors: ["#ff5d4e", "#8dc65d"],
        },
      },
    ];

    return {
      totalEnergy,
      weakCount,
      healthyCount,
      chartData,
    };
  }

  const overviewData = useMemo(() => {
    return prepData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [energyData]);

  return (
    <div className="panelOverview">
      <PanelStatsSummary data={overviewData}/>
      <PanelStatusChart chartData={overviewData.chartData} title="Solar Panel Status" />
    </div>
  );
};

export default ParkOverview;
