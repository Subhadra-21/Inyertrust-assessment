import Plot from "react-plotly.js";
import {useState, useEffect} from 'react';

const PanelStatusChart = ({ chartData, title }) => {
  const [legendText, setLegendText] = useState({
    x: 0.2,
    y: -0.5,
  });

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const newLegendText = width >= 768 ? {
        x: 1,
        y: 1,
      } : {
        x: 0.2,
        y: -0.5,
      };
      setLegendText(newLegendText);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  const layout = {
    width: 370,
    height: 300,
    title: title,
    showlegend: true,
    legend: legendText,
  };
  return <Plot layout={layout} data={chartData} />;
};

export default PanelStatusChart;
