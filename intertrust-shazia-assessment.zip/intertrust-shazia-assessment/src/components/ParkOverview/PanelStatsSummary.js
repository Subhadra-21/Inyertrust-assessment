import "./PanelStatsSummary.css";

const PanelStatsSummary = ({data}) => {
  return (
    <div className="statsContainer">
        <p data-testid={`stats-total`}>Total Energy: {data.totalEnergy} kWh</p>
        <p data-testid={`stats-weak`}>Weak Panel Count: {data.weakCount}</p>
        <p data-testid={`stats-healthy`}>Healthy Panel Count: {data.healthyCount}</p>
    </div>
  )
}

export default PanelStatsSummary