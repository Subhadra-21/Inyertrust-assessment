const moment = require('moment');
const express = require('express');
const app = express();
const port = 5000
const panels = require('./db/producedEnergy.js');

function random(min,max){
    return (Math.random()*(max-min+1)+min).toFixed(2);
}

app.get('/getEnergyData', (_, res) => {
    let freshData = []
    panels.data.forEach(panel => {
        freshData.push({ 
            ...panel,
            time: moment().toISOString(),
            wattage: random(0, 400),
            voltage: random(0,20)
        })
    })
    res.status(200).send(freshData);
  })
  
  app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
  })
